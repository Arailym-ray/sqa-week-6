package org.example;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.MalformedURLException;
import java.net.URL;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {

        public static void main(String[] args) throws MalformedURLException {
            DesiredCapabilities capabilities = new DesiredCapabilities();
            capabilities.setCapability("platformName", "Android");
            capabilities.setCapability("platformVersion", "13.0");
            capabilities.setCapability("deviceName", "Pixel XL API 33");
            capabilities.setCapability("appPackage", "com.example.myapplication");
            capabilities.setCapability("appActivity", "com.example.myapplication.MainActivity");
            // Set other desired capabilities as needed

            AppiumDriver driver;

            driver = new AndroidDriver(new URL("http://localhost:4723/wd/hub"), capabilities);

            System.out.println(driver);
            System.out.println(driver.getCapabilities());
    }
}
/*d*/
