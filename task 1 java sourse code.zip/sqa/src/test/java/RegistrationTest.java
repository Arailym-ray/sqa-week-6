import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class RegistrationTest {
    private AppiumDriver driver;

    @BeforeTest
    public void setUp() throws MalformedURLException {
        DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
        desiredCapabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        desiredCapabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Pixel XL API 33");
        desiredCapabilities.setCapability("appPackage", "com.example.simpleloginandregistrationapp");
        desiredCapabilities.setCapability("appActivity", "com.example.simpleloginandregistrationapp.Login");
        desiredCapabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UiAutomator2");

        URL appiumServerURL = new URL("http://localhost:4723/wd/hub");
        driver = new AndroidDriver(appiumServerURL, desiredCapabilities);
    }

    @Test
    public void testRegistrationSuccess() {
        String username = "almira";
//        String email = "testuser123@example.com";
        String password = "almira";

        WebElement loginRegisterButton = driver.findElement(By.id(("btn_login")));
        loginRegisterButton.click();

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        WebElement usernameField = driver.findElement(By.id("et_lusername"));
        usernameField.sendKeys(username);

//        WebElement emailField = driver.findElement(By.id("email_field_id"));
//        emailField.sendKeys(email);

        WebElement passwordField = driver.findElement(By.id(("et_lpassword")));
        passwordField.sendKeys(password);

        WebElement loginButton = driver.findElement(By.id(("btn_llogin")));
        loginButton.click();

        // Wait for registration process to complete
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

//        WebElement welcomeMessage = driver.findElement(By.id("welcome_message_id"));
//        String expectedWelcomeMessage = "Welcome, " + username;
//        Assert.assertEquals(expectedWelcomeMessage, welcomeMessage.getText());
//        WebElement message = driver.findElement(By.className("android.widget.Toast"));
        WebElement message = driver.findElement(By.xpath("/hierarchy/android.widget.Toast"));
        String expectedWelcomeMessage = "Login Successful"; //
        assertEquals(expectedWelcomeMessage, message.getText());
    }

    @Test
    public void testRegistrationFailure() {
        String duplicateUsername = "almira";
//        String duplicateEmail = "testuser123@example.com";
        String duplicatePassword = "almira";
        String duplicateConfirmPassword = "almira";
        String username = "almira";
        String password = "almira";


        WebElement loginRegisterButton = driver.findElement(By.id(("btn_lregister")));
        loginRegisterButton.click();

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        WebElement usernameField = driver.findElement(By.id("et_username"));
        usernameField.sendKeys(username);

//        WebElement emailField = driver.findElement(By.id("email_field_id"));
//        emailField.sendKeys(email);

        WebElement passwordField = driver.findElement(By.id(("et_password")));
        passwordField.sendKeys(password);

        WebElement confirmPasswordField = driver.findElement(By.id(("et_cpassword")));
        confirmPasswordField.sendKeys(password);

        WebElement registerButton = driver.findElement(By.id(("btn_register")));
        registerButton.click();

        // Wait for registration process to complete
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

//        WebElement welcomeMessage = driver.findElement(By.id("welcome_message_id"));
//        String expectedWelcomeMessage = "Welcome, " + username;
//        Assert.assertEquals(expectedWelcomeMessage, welcomeMessage.getText());
//        WebElement message = driver.findElement(By.className("android.widget.Toast"));
        WebElement message = driver.findElement(By.xpath("/hierarchy/android.widget.Toast"));
        String expectedWelcomeMessage = "Registered"; //
        assertEquals(expectedWelcomeMessage, message.getText());

        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebElement duplicateUsernameField = driver.findElement(By.id("et_username"));
        duplicateUsernameField.sendKeys(duplicateUsername);

//        WebElement emailField = driver.findElement(By.id("email_field_id"));
//        emailField.sendKeys(email);

        WebElement duplicatePasswordField = driver.findElement(By.id(("et_password")));
        duplicatePasswordField.sendKeys(duplicatePassword);

        WebElement duplicateConfirmPasswordField = driver.findElement(By.id(("et_cpassword")));
        duplicateConfirmPasswordField.sendKeys(duplicateConfirmPassword);

        WebElement AgainRegisterButton = driver.findElement(By.id(("btn_register")));
        AgainRegisterButton.click();

        // Wait for registration process to complete
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

//        WebElement welcomeMessage = driver.findElement(By.id("welcome_message_id"));
//        String expectedWelcomeMessage = "Welcome, " + username;
//        Assert.assertEquals(expectedWelcomeMessage, welcomeMessage.getText());
//        WebElement message = driver.findElement(By.className("android.widget.Toast"));
        WebElement message2 = driver.findElement(By.xpath("/hierarchy/android.widget.Toast"));
        String expectedWelcomeMessage2 = "Username already taken"; //
        assertEquals(expectedWelcomeMessage2, message2.getText());
    }

    @AfterTest
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
