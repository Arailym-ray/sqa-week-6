import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class LoginTest {
    private AppiumDriver driver;

    @BeforeTest
    public void setUp() throws MalformedURLException {
        DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
        desiredCapabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        desiredCapabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Pixel XL API 33");
        desiredCapabilities.setCapability("appPackage", "com.example.simpleloginandregistrationapp");
        desiredCapabilities.setCapability("appActivity", "com.example.simpleloginandregistrationapp.Login");
        desiredCapabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UiAutomator2");

        URL appiumServerURL = new URL("http://localhost:4723/wd/hub");
        driver = new AndroidDriver(appiumServerURL, desiredCapabilities);
    }

    @Test
    public void testLoginSuccess() {
        String loginUsername = "almira";
        String loginPassword = "almira";

        WebElement loginUsernameField = driver.findElement(By.id("et_lusername"));
        loginUsernameField.sendKeys(loginUsername);

        WebElement loginPasswordField = driver.findElement(By.id(("et_lpassword")));
        loginPasswordField.sendKeys(loginPassword);

        WebElement lloginButton = driver.findElement(By.id(("btn_llogin")));
        lloginButton.click();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        WebElement login_message = driver.findElement(By.xpath("/hierarchy/android.widget.Toast"));
        String login_expectedWelcomeMessage = "Login Successful";
        assertEquals(login_expectedWelcomeMessage, login_message.getText());
    }

    @Test
    public void testLoginFailure() {
        String wrongusername = "almira";
        String wrongpassword = "almira1";

        String username = "almira";
        String password = "almira";
        WebElement loginRegisterButton = driver.findElement(By.id(("btn_lregister")));
        loginRegisterButton.click();

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        WebElement usernameField = driver.findElement(By.id("et_username"));
        usernameField.sendKeys(username);

        WebElement passwordField = driver.findElement(By.id(("et_password")));
        passwordField.sendKeys(password);

        WebElement confirmPasswordField = driver.findElement(By.id(("et_cpassword")));
        confirmPasswordField.sendKeys(password);

        WebElement registerButton = driver.findElement(By.id(("btn_register")));
        registerButton.click();

        // Wait for registration process to complete
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebElement message = driver.findElement(By.xpath("/hierarchy/android.widget.Toast"));
        String expectedWelcomeMessage = "Registered"; //
        assertEquals(expectedWelcomeMessage, message.getText());

        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebElement loginButton = driver.findElement(By.id(("btn_login")));
        loginButton.click();

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebElement wrongusernameField = driver.findElement(By.id("et_lusername"));
        wrongusernameField.sendKeys(wrongusername);

        WebElement wrongpasswordField = driver.findElement(By.id("et_lpassword"));
        wrongpasswordField.sendKeys(wrongpassword);

        WebElement wregisterButton = driver.findElement(By.id("btn_llogin"));
        wregisterButton.click();

        // Wait for registration process to complete
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebElement wlogin_message = driver.findElement(By.xpath("/hierarchy/android.widget.Toast"));
        String wlogin_expectedWelcomeMessage = "Invalid username or password";
        assertEquals(wlogin_expectedWelcomeMessage, wlogin_message.getText());
    }

    @AfterTest
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
