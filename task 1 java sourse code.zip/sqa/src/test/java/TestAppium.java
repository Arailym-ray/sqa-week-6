import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;

public class TestAppium {

    private AppiumDriver driver;

    @BeforeClass
    public void setUp() throws MalformedURLException {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("platformName", "Android");
        capabilities.setCapability("automationName", "UiAutomator2");
//        capabilities.setCapability("platformVersion", "UiAutomator2");
        capabilities.setCapability("deviceName", "Android");
        capabilities.setCapability("appPackage", "com.android.settings");
        capabilities.setCapability("appActivity", ".Settings");

        URL appiumServerUrl = new URL("http://localhost:4723/wd/hub");
        driver = new AndroidDriver(appiumServerUrl, capabilities);
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    public void testFindBattery() {
//        WebElement el = driver.findElementByXPath("//*[@text='Battery']");
        WebElement el = driver.findElement(By.xpath("//*[@text=\"Battery\"]"));
        el.click();
    }
}
